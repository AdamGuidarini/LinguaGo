import { Component } from '@angular/core';
import { SearchComponent } from './components/search/search.component';
import { RouterOutlet } from "@angular/router";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    SearchComponent,
    RouterOutlet
],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'LexiGo';
  
  constructor() {
    console.log('Hello!');
  }
}
